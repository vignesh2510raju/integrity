
#include "../header/classes.h"

void UpdateMAP_saveFrame(std::vector<Cylinder> cylinders, 
						 std::vector<Frame> &frames, 
						 std::vector<Landmark> &landmarks, 
						 Eigen::Matrix4d T,
						 Parameters p);







