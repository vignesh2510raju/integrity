#include <vector>
#include <iostream>
#include <map>
#include <Eigen/Dense>

std::vector<Eigen::Matrix4d> read_transformations();